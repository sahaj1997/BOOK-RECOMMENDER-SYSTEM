#Retrieving results from the corpus based on query

import re
import string
import math

import sahaj

N = len(sahaj.dictodoc)
stop_words = ['a', 'an', 'the', 'of', 'in', 'on', 'to', 'and', 'are', 'as', 'at', 'but', 'by', 'do', 'has', 'if', "in" ]                                     #complete stop word list

#---------------------------------------------------------------------------------------------------------------------------------------------------------

'''Function to measure similarity between a query and a document on the basis of a given key.
The parameters 'query' and 'doc' are both dictionaries'''

def similarity(query, doc, C, key, bit):                                                             
    global N
    sim = 0

    #Split query and doc into list of words
    q = query[key]
    if type(doc[key]) == str:
        d = re.sub(r'[^a-z0-9A-Z ]', ' ', doc[key]).lower().split()
    else:
        d = doc
    
    #Q is the no. of matching terms between doc and query for a particular key
    Q = len(set(q).intersection(d))
    common_terms = list((set(q).intersection(d)))

    if common_terms != 0:
        for term in common_terms:
            #n is the number of docs having term i
            if bit == 0:
                n = sahaj.termtodic[term][0]
            else:
                n = sahaj.termtodic2[term][0]
            if (N-n)/n <= 0:
                parameter = -100000
            else:
                parameter = float(N - n)/n
                sim += C + math.log(parameter)
        
    return sim

#---------------------------------------------------------------------------------------------------------------------------------------------------------    

def retrieve_results(query, k, C):

    global stop_words

    #Remove all punctutation
    query["NAME"] = re.sub(r'[^a-z0-9A-Z ]', ' ', query["NAME"])
    query["author"] = re.sub(r'[^a-z0-9A-Z ]', ' ', query["author"])
    
    #Convert query into a list of words
    query["NAME"] = query["NAME"].lower().split()
    query["author"] = query["author"].lower().split()

    relevant_docs = []

    for doc in sahaj.dictodoc:
        '''
        q = query["NAME"] + query["author"]                                 
        d = sahaj.dictodoc[doc]["NAME"] + sahaj.dictodoc[doc]["author"]
        common = len(set(q).intersection(d))

        if (common != 0 and not set(q).intersection(d) <= stop_words):
        '''
        sim_name = similarity(query, sahaj.dictodoc[doc], C, "NAME", 0)                                                          
        sim_author = similarity(query, sahaj.dictodoc[doc], C, "author", 0)                                                      

        relevant_docs.append([doc, sim_name, sim_author])
            
    #Sort docs according to decreasing order of similarity with query
    relevant_docs = sorted(relevant_docs, key = lambda x: x[1]+x[2])[::-1]   

    #Return top k results
    if k <= len(relevant_docs):
        return relevant_docs[:k]
    else:
        return relevant_docs

#---------------------------------------------------------------------------------------------------------------------------------------------------------
    
def recommender(doc_id, k, C, a1, a2, a3, a4, a5):                                                                 

    query = dict(sahaj.dictodoc[doc_id])
    global stop_words
    
    #Convert query into a list of words
    query["NAME"] = query["NAME"].lower().split()
    query["author"] = query["author"].lower().split()
    query["Summary"] = query["Summary"]
    query["CATEGORY"] = query["CATEGORY"].lower().split()
    

    recommended_docs = []

    for doc in sahaj.dictodoc:
        '''
        q = query["NAME"] + query["author"]                                 
        d = sahaj.dictodoc[doc]["NAME"] + sahaj.dictodoc[doc]["author"]
        common = len(set(q).intersection(d))

        if (common != 0 and not set(q).intersection(d) <= stop_words):
        '''
        sim_name = similarity(query, sahaj.dictodoc[doc], C, "NAME", 1)                                                        
        sim_author = similarity(query, sahaj.dictodoc[doc], C, "author", 1)                                                      
        sim_summary = similarity(query, sahaj.dictodoc[doc], C, "Summary", 1)                                                          
        sim_category = similarity(query, sahaj.dictodoc[doc], C, "CATEGORY", 1)
        sim_rating = float(query["Rating"])

        if sim_author == 0:
            a2 = 0
        
        score = a1*sim_name + a2*sim_author + a3*sim_summary + a4*sim_category + a5*sim_rating

        if doc != doc_id:
            recommended_docs.append([doc, score, sim_name, sim_author, sim_summary, sim_category, sim_rating])
            
    #Sort docs according to decreasing order of similarity with query
    recommended_docs = sorted(recommended_docs, key = lambda x: x[1])[::-1]   

    #Return top k results
    if k <= len(recommended_docs):
        return recommended_docs[:k]
    else:
        return recommended_docs

#======================================================================================================================================================
docs = []
'''
query = {"NAME" : ['come', 'back', 'to', 'me'], "author": ['melissa', 'foster']}
doc = {"NAME" : ['come', 'back', 'to', 'me'], "author": ['melissa', 'foster']}
#print sahaj.dictodoc[8348]
print similarity(query, sahaj.dictodoc[8348], 0.3, "author")
'''
'''
query = {"NAME" : 'Come Back to Me', "author": 'Melissa Foster'}
docs = retrieve_results(query, 5, 0.3)
print len(docs)
for i in docs:
    print sahaj.dictodoc[i[0]]["NAME"], sahaj.dictodoc[i[0]]["author"], "\t",i[1]+i[2]

rec = recommender(docs[0][0], 5, 0.3, 1, 1, 1, 1, 1)
print len(rec)
for i in rec:
    print sahaj.dictodoc[i[0]]["NAME"], sahaj.dictodoc[i[0]]["author"], "\t",i[1]
'''
