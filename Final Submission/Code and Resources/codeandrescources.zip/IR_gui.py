from Tkinter import *
import Tkinter, tkFileDialog

import numpy as np

import IR

class Application(Frame):

    def __init__(self, master=None):
        Frame.__init__(self, master)
        #self.master.title("Book Recommender System")
        self.grid()
        self.create_widgets()

    #Command definitions--------------------------------------------------------------------------------------------------------------------------------------------

    def enter_input(self):
        if (not self.text4.get("1.0",END)):
            self.input = ''
        else: 
            self.NAME = self.text4.get("1.0",END)
            self.author = self.text1.get("1.0",END)
            
            query = {}
            query["NAME"] = self.NAME
            query["author"] = self.author
            
            self.text2.configure(state = "normal")
            self.text2.delete('1.0', END)
            self.text2.configure(state = "disabled", fg = "Black")

            fp = open("".join(self.NAME.split())+"".join(self.author.split())+"-search"+'.txt', "w")
            print "Search Results:"
            print
            IR.docs = IR.retrieve_results(query, 5, 0.3)
            for j, i in enumerate(IR.docs):
                print j+1, IR.sahaj.dictodoc[i[0]]["NAME"], IR.sahaj.dictodoc[i[0]]["author"], "\t\t",i[1]+i[2]
                fp.write(str(j+1)+ IR.sahaj.dictodoc[i[0]]["NAME"]+ IR.sahaj.dictodoc[i[0]]["author"]+ "\t\t"+str(i[1]+i[2])+"\n")

            fp.close()
        
        return self.NAME, self.author

    def enter_doc_no(self):
        if (not self.text3.get("1.0",END)):
            self.doc_no = ''
        else: 
            self.doc_no = self.text3.get("1.0",END)

        self.text2.configure(state = "normal")
        self.text2.delete('1.0', END)
        self.text2.configure(state = "disabled", fg = "Black")
        self.doc_no = int(self.doc_no)

        fp = open("".join(IR.sahaj.dictodoc[IR.docs[self.doc_no-1][0]]["NAME"].split())+ "".join(IR.sahaj.dictodoc[IR.docs[self.doc_no-1][0]]["author"].split())+"-recommendation"+'.txt', "w")
        print "Recommendations:"
        print
        rec = IR.recommender(IR.docs[self.doc_no-1][0], 10, 0.3, 0.2, 0.6, 0.7, 0.9, 0.5)
        for j, i in enumerate(rec):
            print j+1, IR.sahaj.dictodoc[i[0]]["NAME"], IR.sahaj.dictodoc[i[0]]["author"], "\t\t",i[1]
            fp.write(str(j+1)+ IR.sahaj.dictodoc[i[0]]["NAME"]+ IR.sahaj.dictodoc[i[0]]["author"]+ "\t\t"+str(i[1])+"\n")
        return self.doc_no
    
    #Create Widgets---------------------------------------------------------------------------------------------------------------------------------------
              
    def create_widgets(self):

        #Frames

        Top = Frame(self, width=1000, height=70, bg = "#48d1cc")
        Top.pack(side = TOP)

        Bottom = Frame(self, width=1000, height=300)#, bd = 8)
        Bottom.pack(side = BOTTOM)
        
        Left = Frame(self, width=600, height=70)
        Left.pack(side = LEFT)
        
        Right = Frame(self, width=250, height=70, padx = 20)
        Right.pack(side = RIGHT)

        #Labels

        self.heading_label = Label(Top, text = "BOOK RECOMMENDER", bg = "#48d1cc")
        self.heading_label.config(font=("Ariel", 24, "bold"))
        self.heading_label.place(relx=0.5, rely=0.5, anchor="center")

        self.file_label = Label(Left, text = "Query: ", font = ("Ariel", 10, "bold"))
        self.file_label.grid(row = 0, column = 0, rowspan = 1,columnspan = 1, sticky = W, padx = 20)

        self.Name = Label(Left, text = "Title of the book: ", font = ("Ariel", 10, "bold"))
        self.Name.grid(row = 1, column = 0, rowspan = 1,columnspan = 1, sticky = W, padx = 20)

        self.Author = Label(Left, text = "Author: ", font = ("Ariel", 10, "bold"))
        self.Author.grid(row = 1, column = 1, rowspan = 1,columnspan = 1, sticky = W, padx = 20)

        self.label1 = Label(Bottom, text = "Search Results and Recommendations:", font = ("Ariel", 10, "bold"))
        self.label1.grid(row = 0, column = 0, rowspan = 1,columnspan = 1, sticky = W, padx = 20, pady = 5)

        self.file_label2 = Label(Right, text = "Enter Choice: ", font = ("Ariel", 10, "bold"))
        self.file_label2.grid(row = 0, column = 0, rowspan = 1,columnspan = 1, sticky = W, padx = 20)


        #Textboxes

        self.text4 = Text(Left, width = 25, height = 1)                                                 #Input Textbox
        self.text4.grid(row = 2, column = 0, columnspan = 1, sticky = W,padx = 10)

        self.text1 = Text(Left, width = 25, height = 1)                                                 #Input Textbox
        self.text1.grid(row = 2, column = 1, columnspan = 1, sticky = W, padx = 10)

        '''Output Textbox'''

        #-----    Scrollbar for output textbox
        self.scrollbar1 = Scrollbar(Bottom)
        self.scrollbar1.grid(row=1, column=1, sticky=N+S)
        self.scrollbar2 = Scrollbar(Bottom)
        #self.scrollbar2.grid(row=5, column=0, sticky=W+E)
       
        self.text2 = Text(Bottom, width = 100, height = 30, state="disabled", fg = "Black", wrap = WORD, xscrollcommand=self.scrollbar2.set,yscrollcommand=self.scrollbar1.set)   #Output textbox
        self.text2.grid(row = 1, column = 0, columnspan = 8, sticky = W, padx = (23,0))
        
        #-----    Scrollbar for output textbox
        self.scrollbar2.config(command=self.text2.xview)
        self.scrollbar1.config(command=self.text2.yview)

        #-----    Redirecting CLI output to GUI
        sys.stdout = TextRedirector(self.text2, "stdout")
        sys.stderr = TextRedirector(self.text2, "stderr")

        self.text3 = Text(Right, width = 15, height = 1)                                                 #Input Textbox
        self.text3.grid(row = 0, column = 1, columnspan = 1, sticky = W, pady = 20)


        #Buttons

        self.enter = Button(Left, width = 7, height = 1, text = "ENTER", font = ("Ariel", 7, "bold"), fg = "White", bg = "Black", bd=5,relief = "raise")
        self.enter.configure(command = self.enter_input)
        self.enter.grid(row = 2, column = 3, sticky = W,  pady = 10, columnspan = 2)

        self.enter2 = Button(Right, width = 7, height = 1, text = "ENTER", font = ("Ariel", 7, "bold"), fg = "White", bg = "Black", bd=5,relief = "raise")
        self.enter2.configure(command = self.enter_doc_no)
        self.enter2.grid(row = 0, column = 2, sticky = W,  pady = 10, columnspan = 2)


class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        self.widget = widget
        self.tag = tag

    def write(self, str):
        self.widget.configure(state="normal")
        self.widget.insert("end", str, (self.tag,))
        self.widget.configure(state="disabled")

root = Tk()
root.title = ("Automatic Vegetation Cover Extration")
root.geometry("1000x700+30+30")
root.resizable(width=True, height=True)

#app = DisplaySubprocessOutputDemo(root)
app = Application(root)
root.mainloop()
