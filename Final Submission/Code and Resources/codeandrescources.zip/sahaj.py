import json
import unicodedata
import re
import porter


with open('dataf5.json') as json_file:

    d = json.load(json_file)

'''get stopwords from the stopwords file'''
f=open("stopwords.dat", 'r')
stopwords=[line.rstrip() for line in f]
sw=dict.fromkeys(stopwords)
f.close()

termtodic = dict()
dictodoc = dict()

l1=[]
l2=[]
k=0

for i in d:
        if i["NAME"]== None or i["author"]== None or i["CATEGORY"]== None or i["Rating"]== None or i["Summary"]==None or i["ISBN"]== None :
                continue
        i["NAME"] = unicodedata.normalize('NFKD', i["NAME"]).encode('ascii','ignore')
        i["author"] = unicodedata.normalize('NFKD', i["author"]).encode('ascii','ignore')
        i["CATEGORY"] = unicodedata.normalize('NFKD', i["CATEGORY"]).encode('ascii','ignore')
        i["Rating"] = unicodedata.normalize('NFKD', i["Rating"]).encode('ascii','ignore')
        i["Summary"] = unicodedata.normalize('NFKD', i["Summary"]).encode('ascii','ignore')
        i["ISBN"] = unicodedata.normalize('NFKD', i["ISBN"]).encode('ascii','ignore')
 
        k= k+1
        i["NAME"] =re.sub(r'[^a-z0-9A-Z ]', '', i["NAME"])
        i["author"]=re.sub(r'[^a-z0-9A-Z ]', '', i["author"])
        l2 = i["NAME"].split() + i["author"].split()
        l2 = [x.lower() for x in l2]
        l1 = l1 + l2

for j in l1:
        termtodic[j] =[0,[]]

k=0
for i in d:
        if i["NAME"]== None or i["author"]== None or i["CATEGORY"]== None or i["Rating"]== None or i["Summary"]==None or i["ISBN"]== None :
                continue
        i["Summary"] =re.sub(r'[^a-z0-9A-Z ]', ' ', i["Summary"])
        i["Summary"] = i["Summary"].split()
        i["Summary"] = [x.lower() for x in i["Summary"] if x.lower() not in sw]
        i["Summary"] =[ porter.stem(word) for word in i["Summary"]] 
        seen = []
        for item in i["Summary"]:
                if item not in seen:
                        seen += [item]
        i["Summary"] = seen             

        dictodoc[k] = i  
        k= k+1
        i["NAME"] =re.sub(r'[^a-z0-9A-Z ]', '', i["NAME"])
        i["author"]=re.sub(r'[^a-z0-9A-Z ]', ' ', i["author"])
        l2 = i["NAME"].split() + i["author"].split()
        l2 = [x.lower() for x in l2]
        l1 = l1 + l2
        for j in l2:
                termtodic[j.lower()][0] += 1
                termtodic[j.lower()][1] += [k] 

termtodic2 = dict()
l2=[]

for i in d:
        if i["NAME"]== None or i["author"]== None or i["CATEGORY"]== None or i["Rating"]== None or i["Summary"]==None or i["ISBN"]== None :
                continue

                
        i["CATEGORY"]=re.sub(r'[^a-z0-9A-Z ]', ' ', i["CATEGORY"])      
        l2 = i["NAME"].split() + i["author"].split() + i["CATEGORY"].split() + [i["Rating"]] + i["Summary"]
        l2 = [x.lower() for x in l2]
        l1 = l1 + l2
        
for j in l1:
        termtodic2[j] =[0,[]]

k=0
for i in d:
        if i["NAME"]== None or i["author"]== None or i["CATEGORY"]== None or i["Rating"]== None or i["Summary"]==None or i["ISBN"]== None :
                continue        

        k= k+1
        l2 = i["NAME"].split() + i["author"].split() + i["CATEGORY"].split() + [i["Rating"]] + i["Summary"]
        l2 = [x.lower() for x in l2]
        for j in l2:
                termtodic2[j.lower()][0] += 1
                termtodic2[j.lower()][1] += [k]

#------------------------------------------------------------
'''
#d = dictodoc
d = termtodic2

from itertools import islice

def take(n, iterable):
    "Return first n items of the iterable as a list"
    return list(islice(iterable, n))
n_items = take(1, d.iteritems())
print n_items

#print n_items[0][1][u'NAME']
#print n_items[0][1][u'author']

'''        
